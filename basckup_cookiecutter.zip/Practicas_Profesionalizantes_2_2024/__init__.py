from Practicas_Profesionalizantes_2_2024 import config  # noqa: F401
